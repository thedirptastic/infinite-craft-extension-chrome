browser.runtime.onMessage.addListener(function(message) {
  if (message.action === "addItem") {
    addItemToStorage(message.item);
  }
});

function addItemToStorage(item, emoji) {
  browser.storage.local.get('elements', function(data) {
    var elements = data.elements || [];
    elements.push({text: item, emoji: emoji, discovered: false});
    browser.storage.local.set({elements: elements});
  });
}
